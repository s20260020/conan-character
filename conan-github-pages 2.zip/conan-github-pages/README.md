# 名探偵コナン 性格診断＆キャラクター図鑑

GitHub Pages向けの静的Webサイトです。

## 公開
1. このフォルダの `index.html` をGitHubリポジトリのルートに置く
2. GitHubの **Settings → Pages**
3. Source を **Deploy from a branch**
4. `main` / `/(root)` を選んで Save
5. 公開URLを確認

キャラクター画像は権利上この配布物には同梱していません。公式画像を利用する場合は、利用条件を確認したうえで、`assets` に権利上利用可能な画像を配置して表示部分を差し替えてください。

公式キャラクター情報：
https://www.ytv.co.jp/conan/character/
